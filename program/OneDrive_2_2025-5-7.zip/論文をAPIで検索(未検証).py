import arxiv

def fetch_arxiv_paper(arxiv_id):
    try:
        # 検索クエリを作成
        search = arxiv.Search(id_list=[arxiv_id])

        # 検索結果を取得
        result = next(search.results(), None)

        if result is None:
            print("指定したIDの論文は見つかりませんでした。")
        else:
            print(f"タイトル: {result.title}\n")
            print(f"著者: {', '.join(author.name for author in result.authors)}\n")
            print(f"要約:\n{result.summary}\n")
            print(f"発行日: {result.published}\n")
            print(f"PDFリンク: {result.pdf_url}\n")
    except Exception as e:
        print(f"エラーが発生しました: {e}")

if __name__ == "__main__":
    arxiv_id = input("arXiv IDを入力してください（例: 2101.00001）: ").strip()
    fetch_arxiv_paper(arxiv_id)
