import arxiv
import requests
import fitz  # PyMuPDF
import io

def fetch_arxiv_paper_text(arxiv_id):
    try:
        # arxivから論文情報取得
        search = arxiv.Search(id_list=[arxiv_id])
        result = next(search.results(), None)

        if result is None:
            print("指定したIDの論文は見つかりませんでした。")
            return

        print(f"タイトル: {result.title}\n")
        print(f"PDFリンク: {result.pdf_url}\n")

        # PDFをダウンロード
        response = requests.get(result.pdf_url)
        response.raise_for_status()

        # PDFをテキスト変換
        pdf_file = io.BytesIO(response.content)
        doc = fitz.open(stream=pdf_file, filetype="pdf")

        full_text = ""
        for page in doc:
            full_text += page.get_text()

        # 「証明」や「実験」セクションを簡単に抽出（例）
        extract_sections(full_text)

    except Exception as e:
        print(f"エラーが発生しました: {e}")

def extract_sections(text):
    # 例: 「Proof」「Experiment」セクションを探す
    lower_text = text.lower()

    sections = ['proof', 'experiment', 'experiments', 'evaluation']
    for section in sections:
        if section in lower_text:
            idx = lower_text.find(section)
            snippet = text[idx:idx+2000]  # セクション開始から2000文字だけ表示
            print(f"\n--- {section.title()} セクション抜粋 ---\n")
            print(snippet)
        else:
            print(f"\nセクション '{section}' が見つかりませんでした。")

if __name__ == "__main__":
    arxiv_id = input("arXiv IDを入力してください（例: 2101.00001）: ").strip()
    fetch_arxiv_paper_text(arxiv_id)
