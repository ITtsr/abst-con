import subprocess

# 文章を入手
文章 = input("文章を入力してください: ")

# プログラム1を実行し、文章を入力として渡す
print("Running program1.py...")
proc1 = subprocess.Popen(
    ["python", "program1.py"],
    stdin=subprocess.PIPE,   # 標準入力を設定
    stdout=subprocess.PIPE,  # 標準出力をキャプチャ
    stderr=subprocess.PIPE   # 標準エラーもキャプチャ
)
stdout1, stderr1 = proc1.communicate(input=文章.encode("utf-8"))  # 入力として文章を渡す
if stderr1:
    print(f"Error in program1.py: {stderr1.decode('utf-8').strip()}")

# プログラム2を実行し、プログラム1の出力を入力として渡す
print("Running program2.py...")
proc2 = subprocess.Popen(
    ["python", "program2.py"],
    stdin=subprocess.PIPE,   # 標準入力を設定
    stdout=subprocess.PIPE,  # 標準出力をキャプチャ
    stderr=subprocess.PIPE   # 標準エラーもキャプチャ
)
stdout2, stderr2 = proc2.communicate(input=stdout1)  # 入力としてプログラム1の出力を渡す
if stderr2:
    print(f"Error in program2.py: {stderr2.decode('utf-8').strip()}")

# 最後のプログラムを実行し、プログラム2の出力を入力として渡す
print("Running final_program.py...")
final_proc = subprocess.Popen(
    ["python", "final_program.py"],
    stdin=subprocess.PIPE,   # 標準入力を設定
    stdout=subprocess.PIPE,  # 標準出力をキャプチャ
    stderr=subprocess.PIPE   # 標準エラーもキャプチャ
)
final_stdout, final_stderr = final_proc.communicate(input=stdout2)  # 入力としてプログラム2の出力を渡す

# 最終出力を表示
print("Final output:")
print(final_stdout.decode("shift_jis").strip())

# エラーがあれば表示
if final_stderr:
    print(f"Error in final_program.py: {final_stderr.decode('utf-8').strip()}")