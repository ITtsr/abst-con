# program1.py
import sys

文章 = sys.stdin.read().strip()

# データの加工
要約文 = f"{文章} -> 要約後の文章"

print(要約文)  # 標準出力にデータを送る
sys.stderr.write("Program 1 completed.\n")
