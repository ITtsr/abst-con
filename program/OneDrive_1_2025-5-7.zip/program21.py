# program2.py
import sys

# 標準入力からデータを受け取る
input_data = sys.stdin.read().strip()

# データの加工
processed_data = f"{input_data} -> processed by program2"
print(processed_data)  # 加工したデータを標準出力に送る
sys.stderr.write("Program 2 completed.\n")
