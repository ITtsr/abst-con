# final_program.py
import sys

# 標準入力からデータを受け取る
input_data = sys.stdin.read().strip()

# データを利用
print(f"Final Program received: {input_data}")
sys.stderr.write("Final Program completed.\n")